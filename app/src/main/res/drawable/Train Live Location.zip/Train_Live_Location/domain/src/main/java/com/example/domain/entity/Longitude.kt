package com.example.domain.entity

data class Longitude(
    val longitude: Float
)