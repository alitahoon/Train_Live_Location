package com.example.domain.entity

import java.util.Date

data class Comment(
    val id:Int,
    val content:String,
    val img:String,
    val date:Date,
    val userId:Int,
    val postId:Int,
   val adminId:Int





)
