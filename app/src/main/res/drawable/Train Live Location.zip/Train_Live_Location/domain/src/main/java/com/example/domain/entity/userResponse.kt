package com.example.domain.entity

class userResponse : ArrayList<userResponseItem>()