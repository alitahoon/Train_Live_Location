package com.example.domain.entity

data class Location_Response(
    val latitude: Latitude,
    val longitude: Longitude
)