package com.example.domain.entity

data class ScanTicket(

    val scanedOrNot: Boolean
)
