package com.example.domain.entity

data class LocationDetails(val longitude:Float,val latitude:Float) {
}