package com.example.domain.entity

import java.util.*

data class UpComment(

    val id:Int,
    val content:String,
    val img:String,
    val date: Date
)
