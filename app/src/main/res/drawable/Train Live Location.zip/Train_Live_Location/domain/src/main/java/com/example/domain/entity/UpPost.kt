package com.example.domain.entity

data class UpPost(
    val id: Int,
    val content: String,
    val trainNumber: Int,
    val critical: Boolean,
    val img:String


)
