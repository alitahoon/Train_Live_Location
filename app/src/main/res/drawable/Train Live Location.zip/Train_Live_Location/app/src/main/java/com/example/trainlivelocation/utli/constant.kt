package com.example.trainlivelocation.utli

class constant {

    companion object{
        val BASE_URL="https://trainapiegypt.azurewebsites.net/"
    }
}