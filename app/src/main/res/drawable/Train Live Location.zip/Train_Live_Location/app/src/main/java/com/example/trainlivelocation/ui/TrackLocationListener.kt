package com.example.trainlivelocation.ui

interface TrackLocationListener {
    fun onBtnClickListener()
}