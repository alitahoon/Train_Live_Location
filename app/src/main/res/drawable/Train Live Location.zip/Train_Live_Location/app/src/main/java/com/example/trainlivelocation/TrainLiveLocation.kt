package com.example.trainlivelocation

import android.app.Application
import android.content.Context
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
public class TrainLiveLocation : Application() {
}