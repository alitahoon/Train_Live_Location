package com.example.trainlivelocation.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.trainlivelocation.R
import com.example.trainlivelocation.databinding.FragmentOtbCodeVerficationBinding
import com.example.trainlivelocation.databinding.FragmentSignUpBinding
import dagger.hilt.android.AndroidEntryPoint

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [otb_code_verfication.newInstance] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class otb_code_verfication : Fragment(),SignUpListener {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private lateinit var binding: FragmentOtbCodeVerficationBinding
    private val registerViewModel:UserSignUpViewModel? by activityViewModels()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentOtbCodeVerficationBinding.inflate(inflater,container,false)
            .apply {
                this.viewmodel=registerViewModel
            }
        registerViewModel?.setbaseActivity(requireActivity())
        binding.viewmodel?.userSignUpListener=this
        return binding.root
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment otb_code_verfication.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            otb_code_verfication().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    override fun onStartSignUp() {
        TODO("Not yet implemented")
    }

    override fun onSuccessSignUp() {
        TODO("Not yet implemented")
    }

    override fun onOtbCodeSendToUser() {
        binding.CodeVerficationDialogLoadingCodeSending.setVisibility(View.GONE)
        binding.CodeVerficationLayout.setVisibility(View.VISIBLE)
    }

    override fun onVerificationCompleted() {
        binding.CodeVerficationLayout.setVisibility(View.GONE)
        binding.CodeVerficationDialogLoadingDone.setVisibility(View.VISIBLE)
    }

    override fun onVerficationSuccess() {
        findNavController().navigate(R.id.action_otb_code_verfication_to_splash_new_ui3)
    }

    override fun nextBtnClicked(type:String) {
        TODO("Not yet implemented")
    }

    override fun onFailure(message: String) {
        TODO("Not yet implemented")
    }
}