package com.example.trainlivelocation.ui

import androidx.lifecycle.ViewModel

class PostsViewModel :ViewModel(){
}