package com.example.trainlivelocation.ui

interface LiveLocationListener {
    fun onBtnShareTrainLocationClicked()
    fun onBtnTrackTrainLocationClicked()
}